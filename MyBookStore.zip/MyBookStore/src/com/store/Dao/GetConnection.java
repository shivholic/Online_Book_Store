package com.store.Dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class GetConnection {
	
	private static String jdbcUrl = "jdbc:mysql://localhost:3306/mybookstore?useSSL=false";
	private static String jdbcUsername = "root";
	private static String jdbcPassword = "root123";
	private static String jdbcDriver = "com.mysql.jdbc.Driver";
	
	public GetConnection() {
		// TODO Auto-generated constructor stub
	}
	
	
	// Returning Connection object...
	public static Connection getConnection() {
		Connection connection = null;
		
		try {
			Class.forName(jdbcDriver);
			
			if(connection == null) {
				connection = DriverManager.getConnection(jdbcUrl, jdbcUsername, jdbcPassword);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
}
