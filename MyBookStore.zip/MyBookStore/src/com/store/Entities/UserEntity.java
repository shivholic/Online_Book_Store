package com.store.Entities;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.store.Bean.UserBean;
import com.store.Dao.GetConnection;

public class UserEntity {
	
	private static final String ADD_USER = "insert into userDetails(firstname, lastname, phone, email, password) values (?,?,?,?,?)";
	
	// Adding new user to the database...
	
	public void addUser(UserBean bean) {
		try(Connection connection = GetConnection.getConnection(); 
				PreparedStatement pstmt = connection.prepareStatement(ADD_USER)){
				
				pstmt.setString(1, bean.getFirstName());
				pstmt.setString(2, bean.getLastName());
				pstmt.setString(3, bean.getPhone());
				pstmt.setString(4, bean.getEmail());
				pstmt.setString(5, bean.getPassword());
				
				pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
