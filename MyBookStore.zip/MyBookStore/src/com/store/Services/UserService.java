package com.store.Services;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.store.Bean.UserBean;
import com.store.Entities.UserEntity;

public class UserService {
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	/* Initializing instance variables  */
	
	public UserService(HttpServletRequest request, HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}
	
	/* Adding user object into the database */
	
	public void addUser() {
		
		UserEntity entity = new UserEntity();
		
		try {
			String firstname = request.getParameter("firstname");
			String lastname = request.getParameter("lastname");
			String phone = request.getParameter("phone");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			
			UserBean bean = new UserBean(firstname, lastname, phone, email, password);
			entity.addUser(bean);
			
			HttpSession session = request.getSession();
			session.setAttribute("message", "Registration Successful !! ");
			response.sendRedirect("user_signup.jsp");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
